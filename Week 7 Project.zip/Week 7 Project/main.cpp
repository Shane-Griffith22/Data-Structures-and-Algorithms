#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
vector<vector<string>> read_file(vector<string>& course_info){

vector <vector<string>> course_information;
    string line;
    ifstream course_list("CS 300 Course Information.rtf");//open file CS 300 Course information
    if (course_list.is_open()) { // As long as the file is open, loop through and store each line in a position in vector course_info
        while (getline(course_list, line)) {
            course_info.push_back(line);
        }
    }else
        cout << "Unable to open file...";
course_list.close();
    return course_information;
}
 void print_file(){
    vector<string> course_info;
     read_file(course_info);

     sort(course_info.begin(), course_info.end());//Sorts file alphabetically
    for (int i = 0; i < course_info.size(); i++){ // Loops through file and prints it out vector course_info
        cout << course_info.at(i) << endl;
    }

}
void search_file() {
    // initialize variables
    vector<string> course_info;
    read_file(course_info);
    string line;
    string input;
    bool match = false;

        //creates file object and takes user input to check if it exists
    ifstream course_list("CS 300 Course Information.rtf");
    cout << "Which course are you looking for information on?" << endl;
    cin >> input;



// as long as file is open and user input exists in the file, output line
    if (course_list.is_open()) {
        while(getline(course_list, line)){
            if(line.find(input) != string::npos){
                match = true;


                // parses line where user input exists, and stores the one or two objects in pre req1 and 2 if it exists
                string clss = line.substr(0, line.find(','));//name of class object
                string course = line.substr(0, line.find(','));
                string temp = line.substr(line.find(',')+ 1, line.size() + 1);
                string classTitle = temp.substr(0, temp.find(','));
                temp = temp.substr(temp.find(',') + 1, temp.size() + 1);
                string prereqs = temp.substr(temp.find(',') + 1, temp.size() + 1);
                string prereqs1 = temp.substr(0, temp.find(',') + 1);

                cout << clss << " ";
                cout << classTitle << " ";
                cout << "\nPrerequisites: " ;
                cout << prereqs1;
                cout << prereqs << endl;
                break;
            }

        }
        if (match == false){ // if user input is not if file out error message
            cout << "invalid entry. Please enter a valid entry" << endl;
        }
    }


}
    int main() {
        vector<string> course_info;
        int selection;

        do{
            //Display menu
            cout << "1. Load Data Structure." << endl;
            cout << "2. Print Course List." << endl;
            cout << "3. Print Course." << endl;
            cout << "0. Exit Program." << endl;
            cin >> selection;

            // Switch statement for user input against variable selection
            switch (selection){
                case 1:
                    read_file(course_info);
                    cout << "==========================" << endl;
                    cout << "File successfully loaded!" << endl;
                    cout << "==========================" << endl;
                    break;
                case 2:
                    cout << "====================================" << endl;
                    print_file();
                    cout << "====================================" << endl;
                    break;
                case 3:
                    cout << "==========================" << endl;
                    search_file();
                    cout << "==========================" << endl;
                    break;

            }

        }while(selection != '0');

        return 0;
    }
